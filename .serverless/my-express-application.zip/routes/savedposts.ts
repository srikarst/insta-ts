import express, { Request, Response } from "express";

const router = express.Router();
const Instagram = require("instagram-web-api");
const IG_API = require("instagram-private-api");
const ig = new IG_API.IgApiClient();
ig.state.generateDevice("srikar_st");

const client = new Instagram({
  username: "srikar_st",
  password: "Srikarpoiu10$",
});
// ig.account.logout();
router.get("/api/saved", async (req: Request, res: Response) => {
  try {
    const loggedInUser = await ig.account.login("srikar_st", "Srikarpoiu10$");
    // get saved posts
    const savedFeed = ig.feed.saved();
    let posts: any = [];
    var i = 0;
    do {
      const mySavedPosts = await savedFeed.items();
      const mySavedIds = mySavedPosts;
      posts = posts.concat(mySavedIds);
      // console.log(savedFeed.isMoreAvailable());
    } while (savedFeed.isMoreAvailable());

    var arr = [""];
    // var unique = posts.filter(
    //   (
    //     a: any //a.video_codec //a.video_codec
    //   ) =>
    //     // a.caption && a.caption.text.toLowerCase().includes("monster")
    //     a.user.username.toLowerCase().includes("")
    //   // arr.some(
    //   //   (substring) =>
    //   //     a.caption && a.caption.text.toLowerCase().includes(substring)
    //   // )
    // );
    // var unique = posts;
    var videos = 0;

    var media;
    // await client.login().then(async () => {
    //   for (var i in unique) {
    //     await client.unsave({ mediaId: unique[i].id });
    //     // media = await client.getMediaByShortcode({
    //     //   shortcode: unique[i].code,
    //     // });
    //     // if (media.is_video) videos++;
    //   }
    // });
    res.status(201).send({ count2: posts.length });
  } catch (e) {
    console.log(e);
  }
});

export { router as savedPostsRouter };
