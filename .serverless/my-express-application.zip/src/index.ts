const serverless = require("serverless-http");
import { app } from "./app";

module.exports.handler = serverless(app);
