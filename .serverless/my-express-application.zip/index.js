"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var serverless = require("serverless-http");
var app_1 = require("./app");
module.exports.handler = serverless(app_1.app);
